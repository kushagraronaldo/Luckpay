package com.example.loanapi.integration;

import com.example.loanapi.model.LoanResponse;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

@Component
public class LoanApiClient {
    public LoanResponse fetchLoanDetails(String id) {
        String url = "https://demo9993930.mockable.io/loanaccount/" + id;
        RestTemplate restTemplate = new RestTemplate();
        return restTemplate.getForObject(url, LoanResponse.class);
    }
}
