package com.example.loanapi.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import com.example.loanapi.model.LoanResponse;

public interface LoanRepository extends JpaRepository<LoanResponse, String> {}
