package com.example.loanapi.controller;

import com.example.loanapi.model.LoanResponse;
import com.example.loanapi.service.LoanService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api")
public class LoanController {

    @Autowired
    private LoanService service;

    @GetMapping("/loan/{id}")
    public LoanResponse fetchLoan(@PathVariable String id) {
        return service.getLoanDetails(id);
    }
}
