package com.example.loanapi.service;

import com.example.loanapi.integration.LoanApiClient;
import com.example.loanapi.model.LoanResponse;
import com.example.loanapi.repository.LoanRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class LoanService {

    @Autowired
    private LoanApiClient apiClient;

    @Autowired
    private LoanRepository repo;

    public LoanResponse getLoanDetails(String id) {
        LoanResponse response = apiClient.fetchLoanDetails(id);
        return repo.save(response);
    }
}
